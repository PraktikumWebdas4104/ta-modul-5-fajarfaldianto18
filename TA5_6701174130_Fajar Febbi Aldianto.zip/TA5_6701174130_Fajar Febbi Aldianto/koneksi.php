<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "mhs";
	$koneksi = new mysqli($server,$username,$password,$db);
?>