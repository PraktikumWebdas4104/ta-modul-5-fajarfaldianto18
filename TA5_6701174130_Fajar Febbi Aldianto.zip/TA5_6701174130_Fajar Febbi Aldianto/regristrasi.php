<html>
<head>
	<title>Form Regris</title>
	<h2>Regis</h2>
	<hr align="left" size="6px" color="black" width="400px">
</head>
<body>
	<form method="POST">
	<table>
		<tr>
			<td>NIM</td>
			<td>:</td>
			<td><input type="text" name="nim"></td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><input type="text" name="nama"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td>:</td>
			<td><input type="text" name="email"></td>
		</tr>
		<tr>
			<td>JK</td>
			<td>:</td>
			<td><input type="radio" name="jnskel" value="Laki-laki">Laki-laki &nbsp;
				<input type="radio" name="jnskel" value="Perempuan">Perempuan &nbsp;
				</td>
		</tr>
		<tr>
			<td>Program Studi</td>
			<td>:</td>
			<td><select name="prodi" style="width: 160px" required>
				<option value="prod">Program Studi</option>
				<option value="MI">D3 Manajemen Informatika</option>
				<option value="TK">D3 Teknik Komputer</option>
				<option value="PH">D3 Perhotelan</option>
				<option value="DKV">S1 Desain Komunikasi Visual</option>
				<option value="KB">S1 Komunikasi dan Bisnis</option>
			</select></td>
		</tr>
		<tr>
			<td>Hobi</td>
			<td>:</td>
			<td>
				<input type="checkbox" name="hobi" value="mancing">mancing
				<input type="checkbox" name="hobi" value="balap">balap
				<input type="checkbox" name="hobi" value="berantem">berantem
				<input type="checkbox" name="hobi" value="touring">toring
				<input type="checkbox" name="hobi" value="futsal">futsal<br>
			</td>
		</tr>
		<tr>
			<td>Fakultas</td>
			<td>:</td>
			<td><select name="fakultas">
				<option value="fak">Fakultas</option>
				<option value="FIT">Fakultas Ilmu Terapan</option>
				<option value="FIK">Fakultas Industri Kreatif</option>
				<option value="FKB">Fakultas Komunikasi & Bisnis</option>
			</select></td>
		</tr>
		<tr>
			<td>Foto</td>
			<td>:</td>
			<td><input type="file" name="foto" value="foto"></td>
		</tr>
		<tr>
			<td>Pass</td>
			<td>:</td>
			<td><input type="Password" name="pass"></td>
		</tr>

	</table><br>
	<input type="submit" name="submit">
</form>
</body>
</html>

<?php
	if (isset($_POST['submit'])) {
		include"prosesregris.php";
	}
?>